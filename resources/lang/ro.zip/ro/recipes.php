<?php

return array (
  'recipes' => 
  array (
    'excludes' => 
    array (
      'disease' => 'Exclude daca sufera de',
    ),
  ),
);
