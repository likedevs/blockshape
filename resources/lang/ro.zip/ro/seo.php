<?php

return array (
  'description' => 'Testarea Nutrițională și Fiziologică – Unica Sport. Afli în cât timp poţi obţine rezultatul dorit. Știi exact ce și când să mănânci. Aplici recomandările personalizate pentru un mod de viață sănătos.',
  'keywords' => 'regim alimentar, nutriție, alimentație, dietă disociată, cură de slăbire, diete de slăbit, rețete de slăbit, regim disociat, alimentație sănătoasă',
  'title' => 'Regim alimentar - Unica Sport',
);
