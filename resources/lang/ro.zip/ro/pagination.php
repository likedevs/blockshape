<?php

return array (
  'choose_payment' => 'Selectează metoda de plată',
  'finish' => 'Salvează datele',
  'next' => 'Înainte &raquo;',
  'previous' => '&laquo; Înapoi',
);
