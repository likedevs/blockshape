<?php

return array (
  'admin' => 
  array (
    'record' => 
    array (
      'body' => '<strong>:instructor</strong> a trimis o cerere de alimentatie.
<br />
Pentru a vedea documentul, accesati <a href=":url">urmatorul link</a>',
      'hello' => 'Buna, Administrator!',
      'subject' => 'Cerere de alimentaţie in aşteptare',
    ),
  ),
  'instructor' => 
  array (
    'password' => 
    array (
      'body' => 'Parola ta pentru UnicaSport.com este: <strong><u>":password"</u></strong>',
      'hello' => 'Buna, :name',
      'subject' => 'Parola ta UnicaSport',
    ),
  ),
);
